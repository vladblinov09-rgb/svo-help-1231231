# Как выложить сайт в интернет навсегда

Сайт — Node.js-приложение. Ему нужен хостинг, который умеет запускать Node (не статика вроде GitHub Pages).
Ниже три способа — от самого простого к «своему серверу». Все конфиги уже лежат в папке проекта.

---

## Способ 1. Render.com (рекомендую, бесплатно)

1. Зарегистрируйтесь на https://render.com (можно через GitHub).
2. Создайте репозиторий на GitHub и залейте туда папку проекта:
   ```bash
   git init
   git add .
   git commit -m "svo-help"
   git branch -M main
   git remote add origin https://github.com/ВАШ_ЛОГИН/svo-help.git
   git push -u origin main
   ```
   > Файл `.gitignore` уже настроен: `node_modules`, `data.db`, `uploads` в репозиторий не попадут.
3. На Render: **New + → Blueprint** → выберите репозиторий → он прочитает `render.yaml` → **Apply**.
4. Через пару минут получите адрес вида `https://svo-help.onrender.com` — он работает с любого устройства.
5. Зайдите на `https://svo-help.onrender.com/admin`. Пароль задаётся в переменной `ADMIN_PASSWORD` (в `render.yaml` он генерируется случайный — посмотрите его в разделе Environment на Render и вставьте свой).

> Чтобы на новом хостинге сразу были демо-обращения для проверки, добавьте переменную окружения `SEED_DEMO=1` — она создаст 10 тестовых обращений при первом запуске (на уже заполненной базе ничего не делает). Убрать их можно кнопкой «Очистить всё» в панели.

> ⚠️ На бесплатном тарифе Render «засыпает» после ~15 минут без посетителей: первое открытие после паузы занимает 30–60 секунд. Данные при этом сохраняются, но раз в месяц контейнер пересоздаётся — для надёжности включите платный диск (Add Disk → `/app/data`) или периодически скачивайте `data.db`.

## Способ 2. Railway.app

1. Регистрация на https://railway.app (через GitHub).
2. **New Project → Deploy from GitHub repo** → выберите репозиторий.
3. Railway сам определит Node (файл `railway.toml` уже готов).
4. **Settings → Networking → Generate Domain** — получите публичный адрес.
5. **Variables** → добавьте `ADMIN_PASSWORD=ваш_пароль`.
6. Чтобы данные не терялись: **Settings → Volumes → Add Volume**, путь `/app/data`.

## Способ 3. Свой сервер (VPS)

Подойдёт любой VPS от ~200 ₽/мес (Timeweb, Selectel, Hetzner, FirstVPS) с Ubuntu 22.04+:

```bash
# 1. ставим Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# 2. заливаем проект (папку svourist-help) в /var/www/svo-help
cd /var/www/svo-help
npm install --omit=dev

# 3. автозапуск через systemd
sudo tee /etc/systemd/system/svo-help.service > /dev/null <<'EOF'
[Unit]
Description=SVO Help Desk
After=network.target
[Service]
WorkingDirectory=/var/www/svo-help
Environment=ADMIN_PASSWORD=ваш_пароль
Environment=PORT=3000
ExecStart=/usr/bin/node server.js
Restart=always
User=www-data
[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now svo-help
```

4.nginx + домен + бесплатный HTTPS:

```bash
sudo apt install -y nginx
sudo tee /etc/nginx/sites-available/svo-help > /dev/null <<'EOF'
server {
    listen 80;
    server_name ваш-домен.ru;
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        # важно для потоков реального времени (SSE) — отключаем буферизацию
        proxy_buffering off;
        proxy_cache off;
        proxy_read_timeout 24h;
    }
}
EOF
sudo ln -s /etc/nginx/sites-available/svo-help /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d ваш-домен.ru
```

---

## Что проверить после публикации

- [ ] `https://ваш-адрес/` открывается — лендинг с формой
- [ ] `https://ваш-адрес/admin` — панель, вход по вашему паролю
- [ ] `https://ваш-адрес/appeal?id=SV-...` — отслеживание обращения
- [ ] форма создаёт обращение, файлы прикрепляются, ответ из панели приходит
- [ ] счётчик «онлайн на сайте» меняется, если открыть сайт с двух устройств
- [ ] пароль по умолчанию `svo-admin` заменён на свой
- [ ] настроен бэкап файла `data.db` (например, раз в сутки копировать на Яндекс.Диск)

## Если хостинг буферизует потоки (SSE)

Ничего делать не нужно — сайт сам переключается на опрос раз в 6 секунд (в панели вместо `LIVE` будет написано «обновление 6с»), всё продолжает работать.
