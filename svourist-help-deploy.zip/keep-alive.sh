#!/usr/bin/env bash
# Супервизор: держит сервер и публичный туннель живыми.
# Пишет текущую публичную ссылку в PUBLIC_URL.txt.
cd "$(dirname "$0")"
mkdir -p logs
LOG=logs/keepalive.log
CLOUDFLARED=/home/user/cloudflared
ts(){ date '+%Y-%m-%d %H:%M:%S'; }
say(){ echo "[$(ts)] $1" >> "$LOG"; }
now_s(){ date +%s; }

TUNNEL_PID=0
EVER_OK=0          # был ли туннель доступен хоть раз
FAILS=0            # последовательные неудачные проверки

start_tunnel(){
  : > logs/tunnel.log
  nohup "$CLOUDFLARED" tunnel --url http://localhost:3000 --no-autoupdate --protocol http2 --edge-ip-version 4 --ha-connections 4 >> logs/tunnel.log 2>&1 &
  TUNNEL_PID=$!
  say "туннель запущен (pid $TUNNEL_PID), ждём публичный адрес…"
}

wait_url(){
  # ждём до 120 секунд, пока Cloudflare выдаст адрес и он начнёт отдавать 200
  for i in $(seq 1 24); do
    URL=$(grep -oE "https://[a-z0-9-]+\.trycloudflare\.com" logs/tunnel.log | tail -1)
    if [ -n "$URL" ]; then
      echo "$URL" > PUBLIC_URL.txt
      CODE=$(curl -s -4 -o /dev/null --max-time 15 -w "%{http_code}" "$URL/")
      if [ "$CODE" = "200" ]; then
        say "публичная ссылка работает: $URL"
        return 0
      fi
    fi
    sleep 5
  done
  return 1
}

trap 'say "супервизор остановлен (сигнал)"' TERM INT EXIT
say "супервизор запущен"
: > PUBLIC_URL.txt

# первичный старт сервера
if ! curl -s -4 --max-time 4 -o /dev/null http://localhost:3000/ ; then
  say "сервер не отвечает — запуск"
  nohup env SEED_DEMO=1 node server.js >> logs/server.log 2>&1 &
  sleep 3
fi

start_tunnel
wait_url || say "предупреждение: туннель пока не отвечает, продолжаем попытки"

while true; do
  # 0. самолечение: права на cloudflared и модули node
  chmod +x "$CLOUDFLARED" 2>/dev/null || true
  if [ ! -d node_modules ] || ! node -e "require('express')" >/dev/null 2>&1; then
    if ! pgrep -f "npm install --omit=dev" >/dev/null; then
      say "node_modules повреждён — переустановка в фоне"
      nohup npm install --omit=dev --no-audit --no-fund >> logs/npm.log 2>&1 &
    fi
  fi

  # сервер
  if ! curl -s -4 --max-time 4 -o /dev/null http://localhost:3000/ ; then
    say "сервер не отвечает — перезапуск"
    pkill -xf "node server.js" 2>/dev/null
    sleep 1
    nohup env SEED_DEMO=1 node server.js >> logs/server.log 2>&1 &
    sleep 3
  fi

  # процесс туннеля жив?
  if ! kill -0 "$TUNNEL_PID" 2>/dev/null; then
    say "процесс туннеля умер — перезапуск"
    start_tunnel
    wait_url || true
    FAILS=0
  fi

  # публичная ссылка
  URL=$(cat PUBLIC_URL.txt 2>/dev/null)
  if [ -n "$URL" ]; then
    CODE=$(curl -s -4 -o /dev/null --max-time 20 -w "%{http_code}" "$URL/")
    if [ "$CODE" = "200" ]; then
      [ "$EVER_OK" = "0" ] && say "ссылка подтверждена: $URL"
      EVER_OK=1
      FAILS=0
    else
      FAILS=$((FAILS+1))
      say "ссылка отдала $CODE (провал $FAILS)"
      # рестарт только если туннель уже работал и сломался, либо совсем не поднялся
      if [ "$EVER_OK" = "1" ] && [ "$FAILS" -ge 3 ]; then
        say "ссылка сломана — перезапуск туннеля"
        kill "$TUNNEL_PID" 2>/dev/null
        pkill -f "cloudflared tunnel --url http://localhost:3000" 2>/dev/null
        sleep 2
        start_tunnel
        wait_url || true
        FAILS=0
      elif [ "$EVER_OK" = "0" ] && [ "$FAILS" -ge 5 ]; then
        say "туннель так и не поднялся — перезапуск"
        pkill -f "cloudflared tunnel --url http://localhost:3000" 2>/dev/null
        sleep 2
        start_tunnel
        wait_url || true
        FAILS=0
      fi
    fi
  fi

  sleep 20
done
