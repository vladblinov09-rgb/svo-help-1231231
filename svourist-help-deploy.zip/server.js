'use strict';
/*
 * Помощь СВО — сервер приёма обращений
 * Node + Express + SQLite (better-sqlite3) + загрузка файлов (multer)
 */
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');
const Database = require('better-sqlite3');

const ROOT = __dirname;
const PORT = Number(process.env.PORT || 3000);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'svo-admin';
const MAX_FILES = 5;
const MAX_FILE_MB = 10;
const UPLOAD_DIR = path.join(ROOT, 'uploads');
const DB_PATH = path.join(ROOT, 'data.db');

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

/* ---------------- база данных ---------------- */
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS appeals (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  contact TEXT NOT NULL,
  category TEXT NOT NULL,
  subject TEXT DEFAULT '',
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'new',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  first_response_at TEXT
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  appeal_id TEXT NOT NULL,
  author TEXT NOT NULL,
  text TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS attachments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  appeal_id TEXT NOT NULL,
  message_id INTEGER,
  filename TEXT NOT NULL,
  original_name TEXT NOT NULL,
  mime TEXT DEFAULT '',
  size INTEGER DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_appeal ON messages(appeal_id);
CREATE INDEX IF NOT EXISTS idx_att_appeal ON attachments(appeal_id);
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  login TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  pass_hash TEXT NOT NULL,
  salt TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  created_at TEXT NOT NULL
);
`);
// миграция: привязка обращений к личному кабинету
const appealCols = db.prepare('PRAGMA table_info(appeals)').all();
if(!appealCols.some(c => c.name === 'user_id')){
  db.exec('ALTER TABLE appeals ADD COLUMN user_id INTEGER');
}

const now = () => new Date().toISOString();
const CATEGORIES = [
  'Выплаты и компенсации',
  'ВВК и медосвидетельствование',
  'Увольнение и перевод',
  'Документы и справки',
  'Поддержка семей',
  'Другой вопрос'
];
const STATUSES = ['new', 'in_progress', 'answered', 'closed'];
const ALLOWED_EXT = new Set(['.jpg', '.jpeg', '.png', '.webp', '.gif', '.pdf', '.txt', '.doc', '.docx', '.odt', '.rtf', '.zip']);

/* демо-данные, чтобы сразу было видно статистику (SEED_DEMO=1) */
if (process.env.SEED_DEMO === '1') {
  const count = db.prepare('SELECT COUNT(*) AS c FROM appeals').get().c;
  if (count === 0) {
    const demo = [
      ['Игорь', '@igor_petrov', 'ВВК и медосвидетельствование', 'Отказ ВВК, куда обжаловать', 'Прошёл ВВК, получил отказ. Есть выписка из стационара. Как обжаловать и какие документы нужны?', 'new', 1],
      ['Марина', '@marina_s', 'Выплаты и компенсации', 'Не пришла выплата', 'Подала документы месяц назад, выплата так и не поступила. Где проверять статус?', 'answered', 3],
      ['Сергей', '+7 900 123-45-67', 'Увольнение и перевод', 'Увольнение в запас', 'Нужно оформить увольнение по здоровью. Расскажите порядок действий и какие справки собирать.', 'in_progress', 2],
      ['Алексей', '@alex_k', 'Документы и справки', 'Справка о заработке', 'Какая справка нужна для оформления выплаты и где её получить?', 'answered', 2],
      ['Ольга', '@olga_family', 'Поддержка семей', 'Льготы для семьи', 'Какие льготы и выплаты положены семье, куда обращаться?', 'closed', 4],
      ['Дмитрий', '@dmz', 'Выплаты и компенсации', 'Компенсация за период', 'Уточните, за какой период начисляют компенсацию и от чего зависит размер.', 'new', 1],
      ['Виктор', '@viktor71', 'ВВК и медосвидетельствование', 'Повторное прохождение ВВК', 'После отказа хочу пройти повторно. Что нового нужно принести?', 'answered', 2],
      ['Наталья', '@nata_doc', 'Документы и справки', 'Заявление на выплату', 'Помогите правильно заполнить заявление на выплату.', 'closed', 3],
      ['Роман', '@roman_t', 'Увольнение и перевод', 'Перевод по здоровью', 'Какие основания нужны для перевода и кто принимает решение?', 'new', 2],
      ['Анна', '@anna_help', 'Другой вопрос', 'Вопрос по срокам', 'Сколько ждать ответа после подачи документов?', 'answered', 1]
    ];
    const insA = db.prepare('INSERT INTO appeals (id,name,contact,category,subject,message,status,created_at,updated_at,first_response_at) VALUES (?,?,?,?,?,?,?,?,?,?)');
    const insM = db.prepare('INSERT INTO messages (appeal_id,author,text,created_at) VALUES (?,?,?,?)');
    demo.forEach((d, i) => {
      const id = 'SV-DEMO' + String(i + 1).padStart(3, '0');
      const daysAgo = demo.length - i;
      const created = new Date(Date.now() - daysAgo * 36e5 * 8).toISOString();
      insA.run(id, d[0], d[1], d[2], d[3], d[4], d[5], created, created, d[5] === 'new' || d[5] === 'in_progress' ? null : created);
      insM.run(id, 'user', d[4], created);
      if (d[5] === 'answered' || d[5] === 'closed') {
        insM.run(id, 'admin', 'Здравствуйте! Разобрались в вашем вопросе — подготовили памятку по порядку действий. Уточните, пожалуйста, какие документы уже есть на руках?', new Date(Date.now() - daysAgo * 36e5 * 8 + 36e5 * 2).toISOString());
      }
    });
    console.log('[seed] демо-обращения созданы');
  }
}

/* ---------------- загрузка файлов ---------------- */
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, (req.params.appealId ? req.params.appealId + '-' : 'new-') + crypto.randomBytes(8).toString('hex') + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: MAX_FILE_MB * 1024 * 1024, files: MAX_FILES },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (ALLOWED_EXT.has(ext)) cb(null, true);
    else cb(new Error('Неподдерживаемый тип файла: ' + ext));
  }
});

/* ---------------- приложение ---------------- */
const app = express();
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(ROOT, 'public'), { extensions: ['html'] }));

/* --- личный кабинет: пароли и сессии --- */
function hashPassword(pw, salt){ return crypto.scryptSync(String(pw), salt, 64).toString('hex'); }
function makeToken(){ return crypto.randomBytes(24).toString('hex'); }
function userFromReq(req){
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  if(!token) return null;
  const s = db.prepare('SELECT * FROM sessions WHERE token=?').get(token);
  if(!s) return null;
  return db.prepare('SELECT id, login, name, created_at FROM users WHERE id=?').get(s.user_id) || null;
}
function canAccessAppeal(appeal, user){
  if(!appeal.user_id) return true;                       // анонимное обращение — доступ по номеру
  return !!user && user.id === appeal.user_id;           // иное — только владельцу кабинета
}

/* --- простая защита от спама --- */
const hits = new Map();
function rateLimit(key, max, windowMs) {
  const t = Date.now();
  const arr = (hits.get(key) || []).filter(x => t - x < windowMs);
  arr.push(t);
  hits.set(key, arr);
  return arr.length <= max;
}

/* --- админ-токены (в памяти) --- */
const tokens = new Set();
function adminAuth(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  if (token && tokens.has(token)) return next();
  res.status(401).json({ error: 'Нужен вход администратора' });
}

app.post('/api/login', (req, res) => {
  const { password } = req.body || {};
  if (typeof password !== 'string' || !rateLimit('login:' + req.ip, 10, 6e4)) {
    return res.status(429).json({ error: 'Слишком много попыток, попробуйте позже' });
  }
  if (password !== ADMIN_PASSWORD) return res.status(403).json({ error: 'Неверный пароль' });
  const token = crypto.randomBytes(24).toString('hex');
  tokens.add(token);
  res.json({ token });
});

/* --- личный кабинет посетителя: регистрация, вход, выход --- */
app.post('/api/register', (req, res) => {
  try {
    if (!rateLimit('reg:' + req.ip, 5, 6e5)) {
      return res.status(429).json({ error: 'Слишком много попыток, попробуйте позже' });
    }
    const b = req.body || {};
    const name = String(b.name || '').trim();
    const login = String(b.login || '').trim();
    const password = String(b.password || '');
    if (name.length < 2) return res.status(400).json({ error: 'Укажите имя' });
    const loginOk = /^@[\w\d_]{3,}$/.test(login) || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(login);
    if (!loginOk) return res.status(400).json({ error: 'Логин — @username в Telegram или email' });
    if (password.length < 6) return res.status(400).json({ error: 'Пароль не короче 6 символов' });
    if (db.prepare('SELECT id FROM users WHERE lower(login)=lower(?)').get(login)) {
      return res.status(409).json({ error: 'Такой логин уже зарегистрирован — войдите в кабинет' });
    }
    const salt = crypto.randomBytes(16).toString('hex');
    const ts = now();
    const r = db.prepare('INSERT INTO users (login,name,pass_hash,salt,created_at) VALUES (?,?,?,?,?)')
      .run(login, name, hashPassword(password, salt), salt, ts);
    // подтягиваем анонимные обращения, созданные с тем же контактом
    db.prepare('UPDATE appeals SET user_id=? WHERE user_id IS NULL AND lower(contact)=lower(?)').run(r.lastInsertRowid, login);
    const token = makeToken();
    db.prepare('INSERT INTO sessions (token,user_id,created_at) VALUES (?,?,?)').run(token, r.lastInsertRowid, ts);
    res.status(201).json({ token, user: { id: r.lastInsertRowid, login: login, name: name } });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Ошибка регистрации' }); }
});

app.post('/api/login-user', (req, res) => {
  try {
    if (!rateLimit('loginuser:' + req.ip, 10, 6e5)) {
      return res.status(429).json({ error: 'Слишком много попыток, попробуйте позже' });
    }
    const b = req.body || {};
    const login = String(b.login || '').trim();
    const password = String(b.password || '');
    const u = db.prepare('SELECT * FROM users WHERE lower(login)=lower(?)').get(login);
    if (!u || u.pass_hash !== hashPassword(password, u.salt)) {
      return res.status(403).json({ error: 'Неверный логин или пароль' });
    }
    const token = makeToken();
    db.prepare('INSERT INTO sessions (token,user_id,created_at) VALUES (?,?,?)').run(token, u.id, now());
    res.json({ token, user: { id: u.id, login: u.login, name: u.name } });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Ошибка входа' }); }
});

app.post('/api/logout', (req, res) => {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  if (token) db.prepare('DELETE FROM sessions WHERE token=?').run(token);
  res.json({ ok: true });
});

app.get('/api/me', (req, res) => {
  const user = userFromReq(req);
  if (!user) return res.status(401).json({ error: 'Нужен вход в личный кабинет' });
  const appeals = db.prepare('SELECT * FROM appeals WHERE user_id=? ORDER BY updated_at DESC').all(user.id);
  res.json({
    user: user,
    appeals: appeals.map(a => ({
      appeal: a,
      messages: db.prepare('SELECT * FROM messages WHERE appeal_id=? ORDER BY id ASC').all(a.id),
      attachments: db.prepare('SELECT * FROM attachments WHERE appeal_id=? ORDER BY id ASC').all(a.id)
    }))
  });
});

/* --- создание обращения (посетитель) --- */
app.post('/api/appeals', (req, res) => {
  try {
    if (!rateLimit('create:' + req.ip, 10, 6e5)) {
      return res.status(429).json({ error: 'Слишком много обращений подряд. Попробуйте через несколько минут или напишите в Telegram-чат.' });
    }
    upload.array('files', MAX_FILES)(req, res, err => {
      if (err) {
        const msg = err.code === 'LIMIT_FILE_SIZE'
          ? `Файл больше ${MAX_FILE_MB} МБ`
          : err.code === 'LIMIT_FILE_COUNT'
            ? `Можно прикрепить не более ${MAX_FILES} файлов`
            : err.message || 'Ошибка загрузки файла';
        return res.status(400).json({ error: msg });
      }
      try {
        const b = req.body || {};
        const name = String(b.name || '').trim();
        const contact = String(b.contact || '').trim();
        const category = String(b.category || '').trim();
        const subject = String(b.subject || '').trim();
        const message = String(b.message || '').trim();
        const consent = b.consent === 'on' || b.consent === 'true' || b.consent === true;

        // если вошли в личный кабинет — имя и контакт берём из профиля
        const user = userFromReq(req);
        const finalName = name || (user ? user.name : '');
        const finalContact = contact || (user ? user.login : '');

        if (finalName.length < 2) return res.status(400).json({ error: 'Укажите имя' });
        const contactOk = /^@[\w\d_]{3,}$/.test(finalContact) || /^\+?[\d\s()-]{7,}$/.test(finalContact);
        if (!contactOk) return res.status(400).json({ error: 'Укажите @username в Telegram или номер телефона' });
        if (!CATEGORIES.includes(category)) return res.status(400).json({ error: 'Выберите направление' });
        if (message.length < 20) return res.status(400).json({ error: 'Опишите ситуацию подробнее (минимум 20 символов)' });
        if (!consent) return res.status(400).json({ error: 'Нужно согласие на обработку данных' });

        let id;
        do {
          const d = new Date();
          const p = n => String(n).padStart(2, '0');
          id = `SV-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${String(Math.floor(Math.random() * 900) + 100)}`;
        } while (db.prepare('SELECT 1 FROM appeals WHERE id = ?').get(id));

        // обращение привязываем к кабинету, если вошли
        const ts = now();
        db.prepare('INSERT INTO appeals (id,name,contact,category,subject,message,status,created_at,updated_at,user_id) VALUES (?,?,?,?,?,?,?,?,?,?)')
          .run(id, finalName, finalContact, category, subject, message, 'new', ts, ts, user ? user.id : null);
        const msgId = db.prepare('INSERT INTO messages (appeal_id,author,text,created_at) VALUES (?,?,?,?)')
          .run(id, 'user', message, ts).lastInsertRowid;

        (req.files || []).forEach(f => {
          db.prepare('INSERT INTO attachments (appeal_id,message_id,filename,original_name,mime,size,created_at) VALUES (?,?,?,?,?,?,?)')
            .run(id, msgId, f.filename, f.originalname, f.mimetype, f.size, ts);
        });

        broadcastLive();
        broadcastAdmin();
        res.status(201).json({ id, status: 'new' });
      } catch (e) {
        console.error(e);
        res.status(500).json({ error: 'Не удалось сохранить обращение' });
      }
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

/* --- список обращений (админ) --- */
app.get('/api/appeals', adminAuth, (req, res) => {
  const { status, category, q } = req.query;
  let sql = 'SELECT a.*, u.login AS user_login, (SELECT COUNT(*) FROM messages m WHERE m.appeal_id=a.id) AS msg_count, (SELECT COUNT(*) FROM attachments f WHERE f.appeal_id=a.id) AS file_count FROM appeals a LEFT JOIN users u ON u.id = a.user_id';
  const where = [], params = [];
  if (status && STATUSES.includes(status)) { where.push('a.status=?'); params.push(status); }
  if (category) { where.push('a.category=?'); params.push(category); }
  if (q) {
    where.push('(a.id LIKE ? OR a.name LIKE ? OR a.contact LIKE ? OR a.subject LIKE ? OR a.message LIKE ?)');
    const like = '%' + q + '%';
    params.push(like, like, like, like, like);
  }
  if (where.length) sql += ' WHERE ' + where.join(' AND ');
  sql += ' ORDER BY a.updated_at DESC LIMIT 300';
  res.json(db.prepare(sql).all(...params));
});

/* --- детали обращения + переписка (посетитель по номеру и админ) --- */
app.get('/api/appeals/:id', (req, res) => {
  const appeal = db.prepare('SELECT * FROM appeals WHERE id = ?').get(req.params.id);
  if (!appeal) return res.status(404).json({ error: 'Обращение не найдено. Проверьте номер.' });
  if (!canAccessAppeal(appeal, userFromReq(req))) {
    return res.status(403).json({ error: 'Это обращение привязано к другому личному кабинету. Войдите под своим логином.' });
  }
  const messages = db.prepare('SELECT * FROM messages WHERE appeal_id=? ORDER BY id ASC').all(req.params.id);
  const attachments = db.prepare('SELECT * FROM attachments WHERE appeal_id=? ORDER BY id ASC').all(req.params.id);
  res.json({ appeal, messages, attachments });
});

/* --- сообщение в переписку --- */
function addMessage(req, res, author) {
  try {
    upload.array('files', MAX_FILES)(req, res, err => {
      if (err) {
        const msg = err.code === 'LIMIT_FILE_SIZE' ? `Файл больше ${MAX_FILE_MB} МБ` : (err.message || 'Ошибка загрузки файла');
        return res.status(400).json({ error: msg });
      }
      try {
        const appeal = db.prepare('SELECT * FROM appeals WHERE id = ?').get(req.params.id);
        if (!appeal) return res.status(404).json({ error: 'Обращение не найдено' });
        if (author === 'user' && !canAccessAppeal(appeal, userFromReq(req))) {
          return res.status(403).json({ error: 'Это обращение привязано к другому личному кабинету. Войдите под своим логином.' });
        }
        const text = String((req.body || {}).text || '').trim();
        if (text.length < 1 && !(req.files || []).length) return res.status(400).json({ error: 'Пустое сообщение' });
        const ts = now();
        const msgId = db.prepare('INSERT INTO messages (appeal_id,author,text,created_at) VALUES (?,?,?,?)')
          .run(req.params.id, author, text || '(вложение)', ts).lastInsertRowid;
        (req.files || []).forEach(f => {
          db.prepare('INSERT INTO attachments (appeal_id,message_id,filename,original_name,mime,size,created_at) VALUES (?,?,?,?,?,?,?)')
            .run(req.params.id, msgId, f.filename, f.originalname, f.mimetype, f.size, ts);
        });
        let status = appeal.status;
        let firstResponse = appeal.first_response_at;
        if (author === 'admin') {
          if (!firstResponse) firstResponse = ts;
          if (appeal.status !== 'closed') status = 'answered';
        } else {
          status = 'new';
        }
        db.prepare('UPDATE appeals SET status=?, updated_at=?, first_response_at=? WHERE id=?')
          .run(status, ts, firstResponse, req.params.id);
        broadcastAdmin();
        res.status(201).json({ ok: true, status });
      } catch (e) {
        console.error(e);
        res.status(500).json({ error: 'Не удалось сохранить сообщение' });
      }
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
}

app.post('/api/appeals/:id/messages', (req, res) => addMessage(req, res, 'user'));      // посетитель
app.post('/api/appeals/:id/reply', adminAuth, (req, res) => addMessage(req, res, 'admin')); // админ

/* --- смена статуса (админ) --- */
app.patch('/api/appeals/:id', adminAuth, (req, res) => {
  const { status } = req.body || {};
  if (!STATUSES.includes(status)) return res.status(400).json({ error: 'Неизвестный статус' });
  const appeal = db.prepare('SELECT * FROM appeals WHERE id = ?').get(req.params.id);
  if (!appeal) return res.status(404).json({ error: 'Обращение не найдено' });
  db.prepare('UPDATE appeals SET status=?, updated_at=? WHERE id=?').run(status, now(), req.params.id);
  broadcastAdmin();
  res.json({ ok: true, status });
});

/* --- скачивание вложения --- */
app.get('/api/attachments/:id', (req, res) => {
  const att = db.prepare('SELECT * FROM attachments WHERE id = ?').get(req.params.id);
  if (!att) return res.status(404).json({ error: 'Файл не найден' });
  const filePath = path.join(UPLOAD_DIR, path.basename(att.filename));
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Файл не найден' });
  res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(att.original_name)}"`);
  res.sendFile(filePath);
});

/* --- статистика (админ) --- */
app.get('/api/stats', adminAuth, (req, res) => {
  const total = db.prepare('SELECT COUNT(*) c FROM appeals').get().c;
  const byStatus = {};
  STATUSES.forEach(s => { byStatus[s] = db.prepare('SELECT COUNT(*) c FROM appeals WHERE status=?').get(s).c; });
  const byCategory = CATEGORIES.map(c => ({ category: c, count: db.prepare('SELECT COUNT(*) c FROM appeals WHERE category=?').get(c).c }));
  const files = db.prepare('SELECT COUNT(*) c FROM attachments').get().c;
  const messages = db.prepare('SELECT COUNT(*) c FROM messages WHERE author=\'admin\'').get().c;

  // обращения по дням, последние 14 дней
  const daily = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date(Date.now() - i * 864e5);
    const key = d.toISOString().slice(0, 10);
    const c = db.prepare("SELECT COUNT(*) c FROM appeals WHERE substr(created_at,1,10)=?").get(key).c;
    daily.push({ date: key, count: c });
  }

  // среднее время первого ответа (в часах)
  const rows = db.prepare("SELECT created_at, first_response_at FROM appeals WHERE first_response_at IS NOT NULL").all();
  let avgHours = null;
  if (rows.length) {
    const sum = rows.reduce((acc, r) => acc + (new Date(r.first_response_at) - new Date(r.created_at)), 0);
    avgHours = Math.round(sum / rows.length / 36e5 * 10) / 10;
  }

  res.json({ total, byStatus, byCategory, files, adminMessages: messages, daily, avgResponseHours: avgHours });
});

/* --- полный сброс данных (админ) --- */
app.post('/api/reset', adminAuth, (req, res) => {
  const { confirm } = req.body || {};
  if (confirm !== 'УДАЛИТЬ ВСЁ') return res.status(400).json({ error: 'Нужно подтверждение' });
  db.exec('DELETE FROM messages; DELETE FROM attachments; DELETE FROM appeals;');
  for (const f of fs.readdirSync(UPLOAD_DIR)) {
    try { fs.unlinkSync(path.join(UPLOAD_DIR, f)); } catch (e) {}
  }
  broadcastLive();
  broadcastAdmin();
  res.json({ ok: true });
});

/* --- реальное время: онлайн, статистика, обновления --- */
const onlineMap = new Map();
const liveClients = new Set();
const adminClients = new Set();
const ONLINE_TTL = 30000;

function countOnline(){
  const t = Date.now();
  for(const [id, ts] of onlineMap) if(t - ts > ONLINE_TTL) onlineMap.delete(id);
  return onlineMap.size;
}
function sseWrite(res, obj){
  try{ res.write('data: ' + JSON.stringify(obj) + '\n\n'); }catch(e){}
}
function sseInit(res){
  res.set({ 'Content-Type':'text/event-stream', 'Cache-Control':'no-cache, no-transform', 'Connection':'keep-alive', 'X-Accel-Buffering':'no' });
  if(res.flushHeaders) res.flushHeaders();
}
function publicUrl(){
  try{ return fs.readFileSync(path.join(ROOT, 'PUBLIC_URL.txt'), 'utf8').trim() || null; }
  catch(e){ return null; }
}
function livePayload(){
  const total = db.prepare('SELECT COUNT(*) c FROM appeals').get().c;
  const today = new Date().toISOString().slice(0,10);
  const todayCount = db.prepare("SELECT COUNT(*) c FROM appeals WHERE substr(created_at,1,10)=?").get(today).c;
  const answered = db.prepare("SELECT COUNT(*) c FROM appeals WHERE status IN ('answered','closed')").get().c;
  return { online: countOnline(), total: total, today: todayCount, answered: answered, publicUrl: publicUrl() };
}
function broadcastLive(){ liveClients.forEach(res => sseWrite(res, livePayload())); }
function broadcastAdmin(){ adminClients.forEach(res => sseWrite(res, { type:'update', online: countOnline(), publicUrl: publicUrl() })); }
setInterval(broadcastLive, 3000);
setInterval(countOnline, 10000);

app.post('/api/heartbeat', (req, res) => {
  const id = String((req.body || {}).id || '');
  if(!id || id.length > 64) return res.status(400).json({ error: 'bad id' });
  const before = countOnline();
  onlineMap.set(id, Date.now());
  const after = countOnline();
  res.json(livePayload());
  if(after !== before) broadcastLive();
});

app.get('/api/live', (req, res) => {
  sseInit(res);
  liveClients.add(res);
  sseWrite(res, livePayload());
  req.on('close', () => liveClients.delete(res));
});

app.get('/api/admin-stream', (req, res) => {
  const h = req.headers.authorization || '';
  const token = (h.startsWith('Bearer ') ? h.slice(7) : '') || String(req.query.token || '');
  if(!token || !tokens.has(token)) return res.status(401).end();
  sseInit(res);
  adminClients.add(res);
  sseWrite(res, { type:'update', online: countOnline() });
  req.on('close', () => adminClients.delete(res));
});

/* --- страницы --- */
app.get(['/admin', '/admin/'], (req, res) => res.sendFile(path.join(ROOT, 'public', 'admin.html')));
app.get(['/appeal', '/appeal/'], (req, res) => res.sendFile(path.join(ROOT, 'public', 'appeal.html')));
app.get(['/lk', '/lk/', '/cabinet', '/cabinet/'], (req, res) => res.sendFile(path.join(ROOT, 'public', 'lk.html')));
app.get('/', (req, res) => res.sendFile(path.join(ROOT, 'public', 'index.html')));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Ошибка сервера' });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Сервер запущен: http://localhost:${PORT}`);
  console.log(`Админ-панель: http://localhost:${PORT}/admin  (пароль по умолчанию: ${ADMIN_PASSWORD})`);
});
